#!/usr/bin/env bash
#
# slopblocker uninstaller.
#
#   ./uninstall.sh            remove the program and the service, keep config
#   ./uninstall.sh --purge    also delete the config file
#
set -euo pipefail

PURGE=0
for arg in "$@"; do
    case "$arg" in
        --purge) PURGE=1 ;;
        -h|--help) sed -n '2,7p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
        *) echo "unknown option: $arg" >&2; exit 2 ;;
    esac
done

PREFIX="${HOME}/.local/lib/slopblocker"
CONFIG_DIR="${XDG_CONFIG_HOME:-$HOME/.config}/slopblocker"
UNIT_DIR="${XDG_CONFIG_HOME:-$HOME/.config}/systemd/user"

echo "==> stopping slopblocker"
systemctl --user disable --now slopblocker.service 2>/dev/null || true
rm -f "${UNIT_DIR}/slopblocker.service"
systemctl --user daemon-reload 2>/dev/null || true

echo "==> removing ${PREFIX}"
rm -rf "${PREFIX}"
rm -f "${HOME}/.local/bin/slopblocker"

if [ "${PURGE}" -eq 1 ]; then
    echo "==> removing ${CONFIG_DIR}"
    rm -rf "${CONFIG_DIR}"
else
    echo "==> kept ${CONFIG_DIR} (use --purge to delete it)"
fi

echo "done"
