"""Fullscreen warning image.

Runs as its own process (``python3 -m slopblocker overlay``) so that a Tk
mainloop can never stall the watcher, and so the image can outlive the death of
the window it is punishing.

Backends, in order of preference: Tk (needs python3-tk, exact scaling via
Pillow when present), feh, imv.
"""

from __future__ import annotations

import importlib.util
import logging
import shutil
import subprocess
import time
from pathlib import Path
from typing import Optional, Tuple

log = logging.getLogger(__name__)

_EXTERNAL_FLAGS = {
    "feh": ["--fullscreen", "--no-menus", "--hide-pointer", "--auto-zoom"],
    "imv": ["-f"],
}


def available() -> dict:
    """What could render an overlay on this machine."""
    return {
        "tk": importlib.util.find_spec("tkinter") is not None,
        "feh": shutil.which("feh"),
        "imv": shutil.which("imv"),
        "pillow": importlib.util.find_spec("PIL") is not None,
    }


def choose(mode: str = "auto") -> Optional[str]:
    have = available()
    if mode == "none":
        return None
    if mode in ("tk", "feh", "imv"):
        return mode if have.get(mode) else None
    if have["tk"]:
        return "tk"
    if have["feh"]:
        return "feh"
    if have["imv"]:
        return "imv"
    return None


def show(image: Path, duration: float = 1.2, mode: str = "auto") -> str:
    """Display ``image`` fullscreen for ``duration`` seconds. Returns backend."""
    backend = choose(mode)
    if backend is None:
        raise RuntimeError(
            "no overlay backend available: install python3-tk, feh, or imv")
    if backend == "tk":
        _show_tk(Path(image), duration)
    else:
        _show_external(backend, Path(image), duration)
    return backend


# --------------------------------------------------------------------------- #
# Tk backend
# --------------------------------------------------------------------------- #
def _cover(img, width: int, height: int):
    """Scale-and-crop so the image fills the screen without distortion."""
    from PIL import Image

    scale = max(width / float(img.width), height / float(img.height))
    size = (max(1, int(round(img.width * scale))),
            max(1, int(round(img.height * scale))))
    img = img.resize(size, Image.LANCZOS)
    left = (img.width - width) // 2
    top = (img.height - height) // 2
    return img.crop((left, top, left + width, top + height))


def _load_photo(root, image: Path, width: int, height: int):
    try:
        from PIL import Image, ImageTk

        with Image.open(str(image)) as im:
            im.load()
            prepared = _cover(im.convert("RGB"), width, height)
        return ImageTk.PhotoImage(prepared, master=root)
    except ImportError:
        pass
    except Exception as exc:  # noqa: BLE001
        log.warning("Pillow could not open %s: %s", image, exc)

    try:
        import tkinter as tk

        return tk.PhotoImage(file=str(image), master=root)
    except Exception as exc:  # noqa: BLE001
        log.error("could not load image %s: %s", image, exc)
        return None


def _show_tk(image: Path, duration: float) -> None:
    import tkinter as tk

    root = tk.Tk()
    root.title("slopblocker")
    root.configure(bg="black", cursor="none")
    root.overrideredirect(True)
    try:
        root.attributes("-topmost", True)
        root.attributes("-fullscreen", True)
    except tk.TclError:
        pass

    width = root.winfo_screenwidth()
    height = root.winfo_screenheight()
    root.geometry("%dx%d+0+0" % (width, height))

    photo = _load_photo(root, image, width, height)
    if photo is not None:
        label = tk.Label(root, image=photo, bg="black", bd=0,
                         highlightthickness=0)
        label.pack(expand=True)
        # Tk does not keep its own reference; dropping it renders a blank window.
        root._slopblocker_photo = photo  # type: ignore[attr-defined]
    else:
        tk.Label(
            root, text="SLOP DETECTED", fg="#ff2b2b", bg="black",
            font=("DejaVu Sans", 64, "bold"),
        ).pack(expand=True)

    root.lift()
    try:
        root.focus_force()
    except tk.TclError:
        pass

    root.after(max(1, int(duration * 1000)), root.destroy)
    root.mainloop()


# --------------------------------------------------------------------------- #
# external viewers
# --------------------------------------------------------------------------- #
def _show_external(tool: str, image: Path, duration: float) -> None:
    exe = shutil.which(tool)
    if not exe:
        raise RuntimeError("%s disappeared while starting" % tool)
    cmd = [exe] + _EXTERNAL_FLAGS.get(tool, []) + [str(image)]
    proc = subprocess.Popen(
        cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        start_new_session=True,
    )
    try:
        time.sleep(max(0.05, duration))
    finally:
        if proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=2)
            except subprocess.TimeoutExpired:
                proc.kill()
