"""Minimal X11 backend built on python-xlib.

Only two capabilities are needed: enumerate top-level windows with their
titles, and make one of them cease to exist.

``XKillClient`` tears down the client's X connection, which is as abrupt as it
gets: no save prompt, no WM negotiation, no "are you sure". Because Chrome
multiplexes every window over a single connection, killing one Chrome window
kills the whole process -- that is a deliberate, documented trade-off.
"""

from __future__ import annotations

import logging
import shutil
import subprocess
from dataclasses import dataclass
from typing import List, Optional

log = logging.getLogger(__name__)


class X11Unavailable(RuntimeError):
    """No usable X display, or python-xlib is missing."""


@dataclass(frozen=True)
class WindowInfo:
    id: int
    title: str
    wm_class: str = ""
    pid: Optional[int] = None

    @property
    def hex_id(self) -> str:
        return "0x%x" % self.id

    def __str__(self) -> str:
        return "%s [%s] %s" % (self.hex_id, self.wm_class, self.title)


class X11Session:
    """A long-lived connection to the X server."""

    def __init__(self, display_name: Optional[str] = None,
                 kill_method: str = "auto") -> None:
        try:
            from Xlib import X, display as xdisplay, error as xerror
        except ImportError as exc:  # pragma: no cover - depends on the host
            raise X11Unavailable(
                "python-xlib is not installed (sudo apt install python3-xlib)"
            ) from exc

        self.X = X
        self.error = xerror
        self.kill_method = kill_method

        try:
            self.display = xdisplay.Display(display_name)
        except Exception as exc:  # noqa: BLE001 - any failure means "no X"
            raise X11Unavailable(
                "cannot open X display %r: %s"
                % (display_name or "<default>", exc)
            ) from exc

        self.root = self.display.screen().root
        self._atoms = {}

    # ------------------------------------------------------------------ #
    # properties
    # ------------------------------------------------------------------ #
    def atom(self, name: str) -> int:
        cached = self._atoms.get(name)
        if cached is None:
            cached = self.display.intern_atom(name)
            self._atoms[name] = cached
        return cached

    def _property(self, window, name: str):
        try:
            return window.get_full_property(
                self.atom(name), self.X.AnyPropertyType)
        except self.error.XError:
            return None
        except (TypeError, ValueError):
            return None

    def _title(self, window) -> str:
        prop = self._property(window, "_NET_WM_NAME")
        if prop is not None:
            value = prop.value
            if isinstance(value, bytes):
                return value.decode("utf-8", "replace")
            return str(value)
        try:
            name = window.get_wm_name()
        except self.error.XError:
            return ""
        if isinstance(name, bytes):
            return name.decode("utf-8", "replace")
        return name or ""

    def _wm_class(self, window) -> str:
        try:
            classes = window.get_wm_class()
        except self.error.XError:
            return ""
        if not classes:
            return ""
        return " ".join(str(part) for part in classes)

    def _pid(self, window) -> Optional[int]:
        prop = self._property(window, "_NET_WM_PID")
        if prop is None:
            return None
        try:
            return int(prop.value[0])
        except (TypeError, IndexError, ValueError):
            return None

    def _is_normal(self, window) -> bool:
        prop = self._property(window, "_NET_WM_WINDOW_TYPE")
        if prop is None:
            return True
        try:
            types = [int(value) for value in prop.value]
        except (TypeError, ValueError):
            return True
        return self.atom("_NET_WM_WINDOW_TYPE_NORMAL") in types

    def _client_list(self) -> List[int]:
        prop = self._property(self.root, "_NET_CLIENT_LIST")
        if prop is not None:
            try:
                return [int(wid) for wid in prop.value]
            except (TypeError, ValueError):
                return []
        # Fallback for very old or unusual window managers.
        try:
            return [child.id for child in self.root.query_tree().children]
        except self.error.XError:
            return []

    # ------------------------------------------------------------------ #
    # public API
    # ------------------------------------------------------------------ #
    def windows(self) -> List[WindowInfo]:
        result: List[WindowInfo] = []
        for wid in self._client_list():
            try:
                window = self.display.create_resource_object("window", wid)
            except Exception:  # noqa: BLE001
                continue
            try:
                title = self._title(window)
                if not title:
                    continue
                if not self._is_normal(window):
                    continue
                result.append(WindowInfo(
                    id=int(wid),
                    title=title,
                    wm_class=self._wm_class(window),
                    pid=self._pid(window),
                ))
            except self.error.XError:
                continue
        return result

    def active_window_id(self) -> Optional[int]:
        prop = self._property(self.root, "_NET_ACTIVE_WINDOW")
        if prop is None:
            return None
        try:
            return int(prop.value[0])
        except (TypeError, IndexError, ValueError):
            return None

    def screen_size(self):
        screen = self.display.screen()
        return screen.width_in_pixels, screen.height_in_pixels

    def kill_window(self, window_id: int) -> str:
        """XKillClient. Returns the mechanism that was used."""
        if self.kill_method in ("auto", "xlib"):
            try:
                self._kill_xlib(window_id)
                return "xkillclient"
            except Exception as exc:  # noqa: BLE001
                if self.kill_method == "xlib":
                    raise
                log.debug("XKillClient failed for 0x%x: %s", window_id, exc)
        self._kill_xdotool(window_id)
        return "xdotool"

    def _kill_xlib(self, window_id: int) -> None:
        # Resource.kill_client() is the documented path; it just issues
        # request.KillClient(resource=self.id) for us. XKillClient takes any
        # resource belonging to the client, so the raw XID works too.
        window = self.display.create_resource_object("window", int(window_id))
        killer = getattr(window, "kill_client", None)
        if killer is not None:
            killer()
        else:
            from Xlib.protocol import request
            request.KillClient(display=self.display, resource=int(window_id))
        self.display.flush()

    def _kill_xdotool(self, window_id: int) -> None:
        exe = shutil.which("xdotool")
        if not exe:
            raise X11Unavailable(
                "XKillClient failed and xdotool is not installed "
                "(sudo apt install xdotool)")
        proc = subprocess.run(
            [exe, "windowkill", str(window_id)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            timeout=10,
        )
        if proc.returncode != 0:
            raise X11Unavailable(
                "xdotool windowkill failed: %s"
                % proc.stderr.decode("utf-8", "replace").strip())

    def close_window(self, window_id: int) -> None:
        """Polite close: ask the window manager to send WM_DELETE_WINDOW."""
        from Xlib import protocol
        window = self.display.create_resource_object("window", int(window_id))
        event = protocol.event.ClientMessage(
            window=window,
            client_type=self.atom("_NET_CLOSE_WINDOW"),
            data=(32, [self.X.CurrentTime, 2, 0, 0, 0]),
        )
        self.root.send_event(
            event,
            event_mask=(self.X.SubstructureRedirectMask
                        | self.X.SubstructureNotifyMask),
        )
        self.display.flush()

    def ping(self) -> bool:
        try:
            self.display.sync()
            return True
        except Exception:  # noqa: BLE001
            return False

    def close(self) -> None:
        try:
            self.display.close()
        except Exception:  # noqa: BLE001
            pass
