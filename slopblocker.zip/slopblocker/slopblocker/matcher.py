"""Title matching.

Standard library only -- this module must be importable on a machine with no
X server at all, which is what makes it testable and what lets
``slopblocker match "some title"`` work for triage on any OS.

Matching rules:
  * the title is folded to ASCII lowercase ("Şarkıyı" -> "sarkiyi")
  * whitespace is collapsed
  * a trailing browser suffix (" - Google Chrome") is stripped
  * each pattern becomes a word-boundary phrase regex, so "guess the song"
    matches "Guess-The-Song" but not "guess the songs"
  * a "re:" prefix means the rest is a raw regular expression
  * allowlist phrases suppress an otherwise matching title by substring
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass
from typing import List, Optional, Pattern, Sequence, Tuple

# Turkish letters that NFKD does not decompose usefully.
_TURKISH_FOLD = str.maketrans({
    "\u0131": "i",  # ı dotless i
    "\u0130": "i",  # İ capital dotted I
    "\u015f": "s",  # ş
    "\u015e": "s",  # Ş
    "\u011f": "g",  # ğ
    "\u011e": "g",  # Ğ
    "\u00e7": "c",  # ç
    "\u00c7": "c",  # Ç
    "\u00f6": "o",  # ö
    "\u00d6": "o",  # Ö
    "\u00fc": "u",  # ü
    "\u00dc": "u",  # Ü
    "\u00e2": "a",  # â
    "\u00ee": "i",  # î
    "\u00fb": "u",  # û
})

_WHITESPACE = re.compile(r"\s+")

#: Browser title suffixes Chrome and friends append.
_BROWSER_SUFFIXES: Tuple[str, ...] = (
    " - google chrome",
    " \u2014 google chrome",
    " - google chrome beta",
    " - google chrome (incognito)",
    " - chromium",
    " - chrome",
    " - microsoft edge",
    " - brave",
    " - vivaldi",
    " - opera",
    " - mozilla firefox",
    " - firefox",
)


def fold(text: str) -> str:
    """Lowercase + strip accents + collapse whitespace."""
    if not text:
        return ""
    text = text.translate(_TURKISH_FOLD)
    text = unicodedata.normalize("NFKD", text)
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    text = text.casefold()
    return _WHITESPACE.sub(" ", text).strip()


def strip_browser_suffix(title: str) -> str:
    """Remove a trailing ' - Google Chrome' style suffix, if present."""
    text = (title or "").strip()
    low = text.lower()
    for suffix in _BROWSER_SUFFIXES:
        if low.endswith(suffix):
            return text[: -len(suffix)].rstrip(" -\u2014|")
    return text


def _phrase_regex(phrase: str) -> Pattern:
    """Compile an already-folded phrase into a word-boundary regex.

    Words are joined by "anything that is not a word character", so
    "this or that" also matches "this-or-that", "this | that" and
    "this... or ... that" -- the separators Chrome titles actually use.
    """
    words = [re.escape(word) for word in phrase.split()]
    body = r"[^\w]+".join(words) if words else re.escape(phrase)
    return re.compile(r"(?<!\w)" + body + r"(?!\w)")


def _bounded_regex(expr: str) -> Pattern:
    """Wrap a raw regex in word boundaries."""
    return re.compile(r"(?<!\w)(?:" + expr + r")(?!\w)", re.IGNORECASE)


def _substring_regex(phrase: str) -> Pattern:
    return re.compile(re.escape(phrase))


@dataclass(frozen=True)
class MatchResult:
    """Outcome of checking a single title."""

    matched: bool
    title: str = ""
    folded_title: str = ""
    pattern: Optional[str] = None
    allowlisted_by: Optional[str] = None

    def __bool__(self) -> bool:  # lets callers write ``if result:``
        return self.matched

    def describe(self) -> str:
        if self.matched:
            return "MATCH  %r  (pattern: %s)" % (self.title, self.pattern)
        if self.allowlisted_by:
            return "ALLOW  %r  (rescued by: %s)" % (self.title, self.allowlisted_by)
        return "OK     %r" % (self.title,)


class Matcher:
    """Compiled set of slop patterns plus the allowlist that rescues them."""

    def __init__(self, patterns: Sequence[str], allowlist: Sequence[str] = ()):
        self.patterns: List[str] = [p.strip() for p in patterns if p and p.strip()]
        self.allowlist: List[str] = [p.strip() for p in allowlist if p and p.strip()]

        self._compiled: List[Tuple[Pattern, str]] = []
        for pattern in self.patterns:
            if pattern.startswith("re:"):
                expr = pattern[3:].strip()
                if expr:
                    self._compiled.append((_bounded_regex(expr), pattern))
                continue
            folded = fold(pattern)
            if folded:
                self._compiled.append((_phrase_regex(folded), pattern))

        self._allowed: List[Tuple[Pattern, str]] = []
        for phrase in self.allowlist:
            if phrase.startswith("re:"):
                expr = phrase[3:].strip()
                if expr:
                    self._allowed.append(
                        (re.compile(expr, re.IGNORECASE), phrase))
                continue
            folded = fold(phrase)
            if folded:
                self._allowed.append((_substring_regex(folded), phrase))

    def check(self, title: str) -> MatchResult:
        if not title or not title.strip():
            return MatchResult(False, title=title or "", folded_title="")

        folded = fold(strip_browser_suffix(title))

        for regex, raw in self._allowed:
            if regex.search(folded):
                return MatchResult(
                    False, title=title, folded_title=folded, allowlisted_by=raw)

        for regex, raw in self._compiled:
            if regex.search(folded):
                return MatchResult(
                    True, title=title, folded_title=folded, pattern=raw)

        return MatchResult(False, title=title, folded_title=folded)

    def is_blocked(self, title: str) -> bool:
        return self.check(title).matched

    def __len__(self) -> int:
        return len(self._compiled)
