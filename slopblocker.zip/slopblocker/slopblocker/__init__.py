"""slopblocker - kill slop videos before they eat your evening.

A small X11 daemon that watches Chrome window titles for a configurable list of
"slop video" patterns ("guess the song", "smash or pass", "bu mu şu mu", ...)
and, on a match, flashes a warning image and forcibly kills the window.
"""

__version__ = "0.1.0"

APP_NAME = "slopblocker"
