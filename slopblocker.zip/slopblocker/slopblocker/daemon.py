"""The polling loop.

Deliberately simple: read the window list once per interval, check each title,
punish matches. No X event subscriptions, because a poll every 500 ms costs
almost nothing and survives window-manager quirks that PropertyNotify-based
listening does not.
"""

from __future__ import annotations

import logging
import os
import signal
import subprocess
import sys
import time
from typing import Dict, List, Optional, Tuple

from . import config as config_mod
from .matcher import MatchResult, Matcher, fold
from .x11 import WindowInfo, X11Session, X11Unavailable

log = logging.getLogger(__name__)

_MAX_BACKOFF = 10.0


def build_matcher(cfg: "config_mod.Config") -> Matcher:
    return Matcher(cfg.patterns, cfg.allowlist)


def _ignore_title(cfg: "config_mod.Config", title: str) -> bool:
    if not cfg.windows.title_ignore:
        return False
    folded = fold(title)
    return any(fold(token) in folded for token in cfg.windows.title_ignore)


def scan_once(cfg: "config_mod.Config", session: Optional[X11Session] = None,
              matcher: Optional[Matcher] = None) -> List[Tuple[WindowInfo, MatchResult]]:
    """Check every visible window once; return the matches. No side effects."""
    owns_session = session is None
    if session is None:
        session = X11Session(kill_method=cfg.general.kill_method)
    if matcher is None:
        matcher = build_matcher(cfg)

    matches: List[Tuple[WindowInfo, MatchResult]] = []
    try:
        active = session.active_window_id() if cfg.windows.only_active else None
        for window in session.windows():
            if not cfg.windows.accepts_class(window.wm_class):
                continue
            if active is not None and window.id != active:
                continue
            if _ignore_title(cfg, window.title):
                continue
            result = matcher.check(window.title)
            if result:
                matches.append((window, result))
    finally:
        if owns_session:
            session.close()
    return matches


class SlopDaemon:
    def __init__(self, cfg: "config_mod.Config", dry_run: bool = False) -> None:
        self.cfg = cfg
        self.dry_run = dry_run
        self.matcher = build_matcher(cfg)
        self._last_punished: Dict[str, float] = {}
        self._stop = False
        self._session: Optional[X11Session] = None
        self._backoff = 1.0

    # ------------------------------------------------------------------ #
    def run(self) -> int:
        self._install_signal_handlers()
        log.info(
            "watching for %d slop patterns (%d allowlist rescues), "
            "every %.2fs, close_mode=%s%s",
            len(self.matcher), len(self.matcher.allowlist),
            self.cfg.general.poll_interval, self.cfg.general.close_mode,
            ", DRY RUN" if self.dry_run else "",
        )
        if not self.cfg.windows.wm_class_contains:
            log.warning("wm_class_contains is empty: every window is a candidate")

        while not self._stop:
            session = self._ensure_session()
            if session is None:
                self._wait_backoff()
                continue
            try:
                self._scan(session)
            except Exception as exc:  # noqa: BLE001
                log.error("lost the X session (%s); reconnecting", exc)
                self._drop_session()
                self._wait_backoff()
                continue
            self._backoff = 1.0
            self._sleep(self.cfg.general.poll_interval)

        self._drop_session()
        log.info("stopped")
        return 0

    # ------------------------------------------------------------------ #
    def _scan(self, session: X11Session) -> None:
        active = session.active_window_id() if self.cfg.windows.only_active else None
        for window in session.windows():
            if self._stop:
                return
            if not self.cfg.windows.accepts_class(window.wm_class):
                continue
            if active is not None and window.id != active:
                continue
            if _ignore_title(self.cfg, window.title):
                continue
            result = self.matcher.check(window.title)
            if not result:
                continue
            self._punish(session, window, result)

    def _punish(self, session: X11Session, window: WindowInfo,
                result: MatchResult) -> bool:
        key = result.folded_title or fold(window.title)
        now = time.monotonic()
        if now - self._last_punished.get(key, -1e9) < self.cfg.general.cooldown:
            log.debug("cooldown: %r", window.title)
            return False
        self._last_punished[key] = now
        self._prune(now)

        log.warning(
            "SLOP: %s  [%s]  pattern=%r\n          title=%s",
            window.hex_id, window.wm_class, result.pattern, window.title,
        )

        if self.dry_run:
            log.warning("dry run: would close %s and show %s",
                        window.hex_id, self.cfg.general.image)
            return True

        if self.cfg.general.kill_before_overlay:
            self._close(session, window)
            self._overlay(block=False)
        else:
            self._overlay(block=True)
            self._close(session, window)
        return True

    # ------------------------------------------------------------------ #
    def _close(self, session: X11Session, window: WindowInfo) -> None:
        try:
            if self.cfg.general.close_mode == "graceful":
                session.close_window(window.id)
                log.info("sent WM_DELETE_WINDOW to %s", window.hex_id)
            else:
                used = session.kill_window(window.id)
                log.info("closed %s via %s", window.hex_id, used)
        except Exception as exc:  # noqa: BLE001
            log.error("could not close %s: %s", window.hex_id, exc)

    def _overlay(self, block: bool) -> None:
        image = self.cfg.general.image
        if image is None:
            log.debug("no image configured; skipping the warning image")
            return
        cmd = [
            sys.executable, "-m", "slopblocker", "overlay",
            "--image", str(image),
            "--duration", str(self.cfg.general.overlay_duration),
            "--mode", self.cfg.general.overlay_mode,
        ]
        env = os.environ.copy()
        root = str(config_mod.INSTALL_ROOT)
        existing = env.get("PYTHONPATH")
        env["PYTHONPATH"] = root + (os.pathsep + existing if existing else "")
        timeout = max(5.0, self.cfg.general.overlay_duration + 10.0)
        try:
            if block:
                subprocess.run(cmd, env=env, timeout=timeout, check=False,
                               stdout=subprocess.DEVNULL,
                               stderr=subprocess.DEVNULL)
            else:
                subprocess.Popen(cmd, env=env, start_new_session=True,
                                 stdout=subprocess.DEVNULL,
                                 stderr=subprocess.DEVNULL)
        except Exception as exc:  # noqa: BLE001
            log.error("could not show the warning image: %s", exc)

    # ------------------------------------------------------------------ #
    def _ensure_session(self) -> Optional[X11Session]:
        if self._session is not None:
            return self._session
        try:
            self._session = X11Session(
                display_name=os.environ.get("DISPLAY"),
                kill_method=self.cfg.general.kill_method,
            )
        except X11Unavailable as exc:
            log.warning("%s", exc)
            return None
        log.info("connected to X display %r",
                 os.environ.get("DISPLAY") or "<default>")
        return self._session

    def _drop_session(self) -> None:
        if self._session is not None:
            self._session.close()
            self._session = None

    def _wait_backoff(self) -> None:
        self._sleep(self._backoff)
        self._backoff = min(self._backoff * 2, _MAX_BACKOFF)

    def _sleep(self, seconds: float) -> None:
        deadline = time.monotonic() + seconds
        while not self._stop and time.monotonic() < deadline:
            time.sleep(min(0.05, max(0.0, deadline - time.monotonic())))

    def _prune(self, now: float) -> None:
        horizon = now - max(self.cfg.general.cooldown * 4.0, 300.0)
        stale = [key for key, stamp in self._last_punished.items()
                 if stamp < horizon]
        for key in stale:
            del self._last_punished[key]

    def _install_signal_handlers(self) -> None:
        for sig in (signal.SIGTERM, signal.SIGINT):
            try:
                signal.signal(sig, self._handle_signal)
            except (ValueError, OSError):  # not the main thread
                pass

    def _handle_signal(self, _signum, _frame) -> None:
        log.info("shutdown requested")
        self._stop = True
