"""Command line entry point: ``python3 -m slopblocker <command>``."""

from __future__ import annotations

import argparse
import logging
import os
import platform
import shutil
import sys
from pathlib import Path

from . import __version__, config as config_mod
from .matcher import Matcher

EXIT_OK = 0
EXIT_ERROR = 1
EXIT_CONFIG = 2
EXIT_NO_X = 3


# --------------------------------------------------------------------------- #
# helpers
# --------------------------------------------------------------------------- #
def _setup_logging(level: str, log_file: str = None) -> None:
    handlers = [logging.StreamHandler(sys.stderr)]
    if log_file:
        from logging.handlers import RotatingFileHandler

        path = Path(log_file).expanduser()
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            handlers.append(RotatingFileHandler(
                str(path), maxBytes=1_000_000, backupCount=2, encoding="utf-8"))
        except OSError as exc:
            print("warning: cannot write log file %s: %s" % (path, exc),
                  file=sys.stderr)
    logging.basicConfig(
        level=getattr(logging, str(level).upper(), logging.INFO),
        format="%(asctime)s %(levelname)-7s %(message)s",
        handlers=handlers,
    )


def _load_or_fail(path: str) -> "config_mod.Config":
    return config_mod.load(path)


def _print_config_warnings(cfg: "config_mod.Config") -> None:
    for warning in cfg.warnings:
        print("note: %s" % warning, file=sys.stderr)


def _version_string(module, default: str = "unknown") -> str:
    """Best-effort version for a module, tolerating tuples.

    Some distro builds of python-xlib expose ``__version__`` as ``(0, 33)``
    rather than ``"0.33"``, which used to crash ``diagnose`` outright.
    """
    value = getattr(module, "__version__", None)
    if value is None:
        value = getattr(module, "version", default)
    if isinstance(value, (tuple, list)):
        return ".".join(str(part) for part in value)
    return str(value)


# --------------------------------------------------------------------------- #
# commands
# --------------------------------------------------------------------------- #
def _cmd_run(args) -> int:
    from .daemon import SlopDaemon, scan_once
    from .x11 import X11Unavailable

    cfg = _load_or_fail(args.config)
    _setup_logging("DEBUG" if args.verbose else cfg.general.log_level,
                   args.log_file)
    _print_config_warnings(cfg)

    if args.once:
        try:
            matches = scan_once(cfg)
        except X11Unavailable as exc:
            print("error: %s" % exc, file=sys.stderr)
            return EXIT_NO_X
        print("%d window(s) matched:" % len(matches))
        for window, result in matches:
            print("  %s  [%s]  pattern=%s  %s"
                  % (window.hex_id, window.wm_class, result.pattern,
                     window.title))
        return EXIT_OK

    daemon = SlopDaemon(cfg, dry_run=args.dry_run)
    try:
        return daemon.run()
    except X11Unavailable as exc:
        print("error: %s" % exc, file=sys.stderr)
        return EXIT_NO_X


def _cmd_diagnose(args) -> int:
    cfg = _load_or_fail(args.config)
    problems = []

    print("slopblocker %s  environment report" % __version__)
    print("=" * 70)

    rows = [
        ("python", "%s  (%s)" % (sys.version.split()[0], sys.executable)),
        ("platform", "%s %s" % (platform.system(), platform.release())),
        ("DISPLAY", os.environ.get("DISPLAY") or "(unset)"),
        ("XAUTHORITY", os.environ.get("XAUTHORITY") or "(unset)"),
        ("WAYLAND_DISPLAY", os.environ.get("WAYLAND_DISPLAY") or "(unset)"),
        ("XDG_SESSION_TYPE", os.environ.get("XDG_SESSION_TYPE") or "(unset)"),
        ("config", "%s%s" % (
            cfg.path,
            "" if cfg.path and cfg.path.is_file() else "   [missing: defaults]")),
        ("image", str(cfg.general.image) if cfg.general.image else "(none)"),
        ("patterns", str(len(cfg.patterns))),
        ("allowlist", str(len(cfg.allowlist))),
    ]
    for key, value in rows:
        print("%-16s %s" % (key, value))

    # python-xlib
    try:
        import Xlib  # noqa: F401

        have_xlib = True
        print("%-16s ok (%s)" % ("python-xlib", _version_string(Xlib)))
    except ImportError:
        have_xlib = False
        print("%-16s %s" % ("python-xlib", "MISSING  -> sudo apt install python3-xlib"))
        problems.append("python-xlib is not installed")

    # helper binaries
    from . import overlay as overlay_mod

    have = overlay_mod.available()
    helpers = {
        "tkinter": "yes" if have["tk"] else "no (python3-tk)",
        "feh": have["feh"] or "no",
        "imv": have["imv"] or "no",
        "xdotool": shutil.which("xdotool") or "no",
        "Pillow": "yes" if have["pillow"] else "no (optional, nicer scaling)",
    }
    for key, value in helpers.items():
        print("%-16s %s" % (key, value))

    backend = overlay_mod.choose(cfg.general.overlay_mode)
    print("%-16s %s" % ("overlay", "%s -> %s"
                        % (cfg.general.overlay_mode, backend or "NONE")))
    if backend is None:
        problems.append("no overlay backend: install python3-tk or feh")
    if cfg.general.image is None:
        problems.append("no warning image available")

    for warning in cfg.warnings:
        print("%-16s %s" % ("warning", warning))

    # X connection + live window inventory
    print("-" * 70)
    if not have_xlib:
        print("X windows       skipped")
    else:
        from .x11 import X11Session, X11Unavailable

        try:
            session = X11Session(
                display_name=os.environ.get("DISPLAY"),
                kill_method=cfg.general.kill_method)
        except X11Unavailable as exc:
            print("X connection    FAILED: %s" % exc)
            problems.append("cannot open the X display")
        else:
            try:
                width, height = session.screen_size()
                windows = session.windows()
                matcher = Matcher(cfg.patterns, cfg.allowlist)
                candidates = [w for w in windows
                              if cfg.windows.accepts_class(w.wm_class)]
                print("X connection    ok, root %dx%d" % (width, height))
                print("windows         %d total, %d look like Chrome"
                      % (len(windows), len(candidates)))
                for window in windows[:25]:
                    result = matcher.check(window.title)
                    flag = ""
                    if result:
                        flag = "  <-- MATCH: %s" % result.pattern
                    elif not cfg.windows.accepts_class(window.wm_class):
                        flag = "  (ignored: wm_class)"
                    print("  %-10s %-18s %s%s"
                          % (window.hex_id, window.wm_class[:18],
                             window.title[:70], flag))
                if len(windows) > 25:
                    print("  ... %d more" % (len(windows) - 25))
            finally:
                session.close()

    print("-" * 70)
    if problems:
        print("NOT READY: %s" % "; ".join(problems))
        return EXIT_ERROR
    print("ready")
    return EXIT_OK


def _cmd_match(args) -> int:
    cfg = _load_or_fail(args.config)
    matcher = Matcher(cfg.patterns, cfg.allowlist)
    print("%d patterns, %d allowlist entries"
          % (len(matcher), len(matcher.allowlist)))
    exit_code = EXIT_OK
    for title in args.titles:
        result = matcher.check(title)
        print("  " + result.describe())
        if result.matched:
            exit_code = EXIT_OK
    return exit_code


def _cmd_patterns(args) -> int:
    cfg = _load_or_fail(args.config)
    print("# patterns (%d)" % len(cfg.patterns))
    for index, pattern in enumerate(cfg.patterns, 1):
        print("%3d  %s" % (index, pattern))
    print()
    print("# allowlist (%d)" % len(cfg.allowlist))
    for index, phrase in enumerate(cfg.allowlist, 1):
        print("%3d  %s" % (index, phrase))
    return EXIT_OK


def _cmd_overlay(args) -> int:
    from . import overlay as overlay_mod

    image = Path(args.image).expanduser()
    if not image.is_file():
        print("error: no such image: %s" % image, file=sys.stderr)
        return EXIT_ERROR
    try:
        backend = overlay_mod.show(image, args.duration, args.mode)
    except Exception as exc:  # noqa: BLE001
        print("error: %s" % exc, file=sys.stderr)
        return EXIT_ERROR
    print("displayed %s for %.1fs via %s" % (image, args.duration, backend))
    return EXIT_OK


def _cmd_init_config(args) -> int:
    try:
        path = config_mod.write_default_config(args.config, force=args.force)
    except config_mod.ConfigError as exc:
        print("error: %s" % exc, file=sys.stderr)
        return EXIT_CONFIG
    print("wrote %s" % path)
    return EXIT_OK


# --------------------------------------------------------------------------- #
# argument parsing
# --------------------------------------------------------------------------- #
def build_parser() -> argparse.ArgumentParser:
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument(
        "--config", "-c", metavar="PATH", default=argparse.SUPPRESS,
        help="config file (default: ~/.config/slopblocker/config.ini)")

    parser = argparse.ArgumentParser(
        prog="slopblocker",
        description="Kill slop videos by watching Chrome window titles.",
    )
    parser.add_argument("--config", "-c", metavar="PATH",
                        help="config file (default: ~/.config/slopblocker/"
                             "config.ini)")
    parser.add_argument("--version", action="version",
                        version="slopblocker " + __version__)
    sub = parser.add_subparsers(dest="command")

    run = sub.add_parser("run", parents=[common],
                         help="start the watcher (default command)")
    run.add_argument("--dry-run", action="store_true",
                     help="log matches but never close anything")
    run.add_argument("--once", action="store_true",
                     help="scan once, print matches, exit")
    run.add_argument("--log-file", metavar="PATH",
                     help="also append logs to this file")
    run.add_argument("-v", "--verbose", action="store_true",
                     help="debug logging")
    run.set_defaults(func=_cmd_run)

    diag = sub.add_parser("diagnose", parents=[common],
                          help="report the environment and live windows")
    diag.set_defaults(func=_cmd_diagnose)

    match = sub.add_parser("match", parents=[common],
                           help="test titles against the pattern list")
    match.add_argument("titles", nargs="+", metavar="TITLE")
    match.set_defaults(func=_cmd_match)

    patterns = sub.add_parser("patterns", parents=[common],
                              help="print the active patterns")
    patterns.set_defaults(func=_cmd_patterns)

    overlay = sub.add_parser("overlay", parents=[common],
                             help="show the warning image (internal use)")
    overlay.add_argument("--image", required=True)
    overlay.add_argument("--duration", type=float, default=1.2)
    overlay.add_argument("--mode", default="auto")
    overlay.set_defaults(func=_cmd_overlay)

    init = sub.add_parser("init-config", parents=[common],
                          help="write a commented default config file")
    init.add_argument("--force", action="store_true",
                      help="overwrite an existing file")
    init.set_defaults(func=_cmd_init_config)

    return parser


def main(argv=None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if not getattr(args, "command", None):
        parser.print_help()
        return EXIT_OK
    if not hasattr(args, "config"):
        args.config = None
    try:
        return args.func(args)
    except config_mod.ConfigError as exc:
        print("config error: %s" % exc, file=sys.stderr)
        return EXIT_CONFIG
    except KeyboardInterrupt:
        return EXIT_OK


if __name__ == "__main__":
    sys.exit(main())
