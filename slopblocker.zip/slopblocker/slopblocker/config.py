"""Configuration loading for slopblocker.

The format is INI via the standard library ``configparser`` on purpose. The
target machine is a Debian-derived image (Pardus ETAP) which may ship an older
Python where ``tomllib`` does not exist, so nothing here may depend on it.

Every option has a sane default; a missing config file is not an error.
"""

from __future__ import annotations

import configparser
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

APP_NAME = "slopblocker"

PACKAGE_DIR = Path(__file__).resolve().parent
INSTALL_ROOT = PACKAGE_DIR.parent
BUNDLED_IMAGE = INSTALL_ROOT / "assets" / "noslop.png"

#: Conservative defaults: phrases that are almost never a legitimate title.
DEFAULT_PATTERNS: List[str] = [
    # --- English ---
    "guess the song",
    "guess the movie",
    "guess the anime",
    "guess the character",
    "this or that",
    "smash or pass",
    "would you rather",
    "kiss marry kill",
    "truth or dare",
    "never have i ever",
    "try not to laugh",
    "you laugh you lose",
    "try not to cringe",
    "rate my",
    "rating your",
    "tier list",
    "choose one",
    "pick one",
    # --- Turkish ---
    "şarkıyı tahmin et",
    "bu mu şu mu",
    "hangisini seçerdin",
    "hangisi daha",
    "öpücük mü tokat mı",
    "asla asla deme",
    "gülmeyi bırak",
]

#: Suppress a match when the title also contains one of these. Keeps a legit
#: "how to guess the song in 3 chords" tutorial from being executed.
DEFAULT_ALLOWLIST: List[str] = [
    "tutorial",
    "explained",
    "explanation",
    "analysis",
    "documentary",
    "how to",
    "lesson",
    "lecture",
    "breakdown",
    "review of",
    "history of",
    "recipe",
    "ders",
    "anlatım",
]

#: Broader, more trigger-happy patterns. Shipped commented out; the user opts in.
HARSHER_PATTERNS: List[str] = [
    "reacting to",
    "my honest reaction",
    "shorts",
    "compilation",
    "asmr",
    "mukbang",
    "prank",
    "drama",
    "gossip",
]


class ConfigError(Exception):
    """Raised when the config file exists but contains an invalid value."""


def default_config_path() -> Path:
    xdg = os.environ.get("XDG_CONFIG_HOME")
    base = Path(xdg) if xdg else Path.home() / ".config"
    return base / APP_NAME / "config.ini"


# --------------------------------------------------------------------------- #
# small parsing helpers
# --------------------------------------------------------------------------- #
def _split_lines(value: Optional[str]) -> List[str]:
    """Split a multi-line config value into stripped, non-comment lines."""
    out: List[str] = []
    for raw in (value or "").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or line.startswith("//"):
            continue
        out.append(line)
    return out


def _split_csv(value: Optional[str]) -> List[str]:
    if not value:
        return []
    return [part.strip() for part in value.split(",") if part.strip()]


def _get_float(cp: configparser.ConfigParser, section: str, key: str,
               default: float) -> float:
    raw = cp.get(section, key, fallback=None)
    if raw is None or not str(raw).strip():
        return default
    try:
        return float(str(raw).strip())
    except ValueError:
        raise ConfigError("%s.%s must be a number, got %r" % (section, key, raw))


def _get_bool(cp: configparser.ConfigParser, section: str, key: str,
              default: bool) -> bool:
    raw = cp.get(section, key, fallback=None)
    if raw is None or not str(raw).strip():
        return default
    value = str(raw).strip().lower()
    if value in ("1", "yes", "true", "on"):
        return True
    if value in ("0", "no", "false", "off"):
        return False
    raise ConfigError("%s.%s must be true/false, got %r" % (section, key, raw))


def _get_choice(cp: configparser.ConfigParser, section: str, key: str,
                default: str, choices) -> str:
    raw = cp.get(section, key, fallback=None)
    value = (str(raw).strip().lower() if raw else "") or default
    if value not in choices:
        raise ConfigError(
            "%s.%s must be one of %s, got %r"
            % (section, key, ", ".join(sorted(choices)), raw)
        )
    return value


def _is_truthy(value: bool) -> bool:
    return bool(value)


# --------------------------------------------------------------------------- #
# resolved configuration
# --------------------------------------------------------------------------- #
@dataclass
class GeneralConfig:
    poll_interval: float = 0.5
    cooldown: float = 30.0
    close_mode: str = "kill"           # kill | graceful
    kill_method: str = "auto"          # auto | xlib | xdotool
    kill_before_overlay: bool = True
    overlay_duration: float = 1.2
    overlay_mode: str = "auto"         # auto | tk | feh | imv | none
    image: Optional[Path] = None
    image_configured: bool = False
    log_level: str = "INFO"


@dataclass
class WindowConfig:
    wm_class_contains: List[str] = field(
        default_factory=lambda: ["chrome", "chromium"]
    )
    title_ignore: List[str] = field(default_factory=list)
    only_active: bool = False

    def accepts_class(self, wm_class: str) -> bool:
        if not self.wm_class_contains:
            return True
        low = (wm_class or "").lower()
        return any(token in low for token in self.wm_class_contains)


@dataclass
class Config:
    path: Optional[Path]
    general: GeneralConfig
    windows: WindowConfig
    patterns: List[str]
    allowlist: List[str]
    warnings: List[str] = field(default_factory=list)


def _resolve_image(raw: str, config_path: Optional[Path]) -> tuple:
    """Resolve the configured image path.

    Returns ``(path_or_None, was_configured)``. A bare filename is looked up
    next to the config file, then next to the installed package, then in the
    current directory -- so ``image = my.png`` just works.
    """
    if not raw or not raw.strip():
        return (BUNDLED_IMAGE if BUNDLED_IMAGE.is_file() else None), False

    expanded = Path(os.path.expandvars(os.path.expanduser(raw.strip())))
    if expanded.is_absolute():
        return (expanded if expanded.is_file() else None), True

    candidates = []
    if config_path is not None:
        candidates.append(config_path.parent / expanded)
    candidates.append(INSTALL_ROOT / expanded)
    candidates.append(Path.cwd() / expanded)
    for candidate in candidates:
        if candidate.is_file():
            return candidate.resolve(), True
    return None, True


def load(path: Optional[str] = None) -> Config:
    """Load configuration, falling back to built-in defaults."""
    config_path = Path(path).expanduser() if path else default_config_path()
    cp = configparser.RawConfigParser(
        comment_prefixes=("#", ";"),
        inline_comment_prefixes=None,
        strict=False,
    )
    warnings: List[str] = []

    exists = config_path.is_file()
    if exists:
        try:
            cp.read(str(config_path), encoding="utf-8")
        except (OSError, configparser.Error) as exc:
            raise ConfigError("could not read %s: %s" % (config_path, exc))
    else:
        warnings.append("config file not found, using built-in defaults: %s"
                        % config_path)

    general = GeneralConfig()
    general.poll_interval = _get_float(cp, "general", "poll_interval", 0.5)
    general.cooldown = _get_float(cp, "general", "cooldown", 30.0)
    general.close_mode = _get_choice(
        cp, "general", "close_mode", "kill", ("kill", "graceful"))
    general.kill_method = _get_choice(
        cp, "general", "kill_method", "auto", ("auto", "xlib", "xdotool"))
    general.kill_before_overlay = _get_bool(
        cp, "general", "kill_before_overlay", True)
    general.overlay_duration = _get_float(cp, "general", "overlay_duration", 1.2)
    general.overlay_mode = _get_choice(
        cp, "general", "overlay_mode", "auto", ("auto", "tk", "feh", "imv", "none"))
    general.log_level = str(
        cp.get("general", "log_level", fallback="INFO") or "INFO").strip().upper()

    if general.poll_interval < 0.05:
        warnings.append("poll_interval %.3f is too aggressive, clamped to 0.05"
                        % general.poll_interval)
        general.poll_interval = 0.05
    if general.cooldown < 0:
        raise ConfigError("general.cooldown must be >= 0")
    if general.overlay_duration < 0:
        raise ConfigError("general.overlay_duration must be >= 0")

    raw_image = cp.get("general", "image", fallback="")
    general.image, general.image_configured = _resolve_image(raw_image, config_path)
    if general.image_configured and general.image is None:
        warnings.append("configured image not found: %r" % raw_image)
    if general.image is None:
        warnings.append(
            "no warning image available; matched windows will still be killed")

    windows = WindowConfig()
    windows.wm_class_contains = _split_csv(
        cp.get("windows", "wm_class_contains", fallback="chrome, chromium"))
    windows.title_ignore = _split_lines(
        cp.get("windows", "title_ignore", fallback=""))
    windows.only_active = _get_bool(cp, "windows", "only_active", False)

    patterns: List[str] = []
    if cp.has_section("patterns"):
        for _key, value in cp.items("patterns"):
            patterns.extend(_split_lines(value))
    if not patterns:
        patterns = list(DEFAULT_PATTERNS)

    allowlist: List[str] = []
    if cp.has_section("allowlist"):
        for _key, value in cp.items("allowlist"):
            allowlist.extend(_split_lines(value))
    if not allowlist:
        allowlist = list(DEFAULT_ALLOWLIST)

    return Config(
        path=config_path if exists else config_path,
        general=general,
        windows=windows,
        patterns=patterns,
        allowlist=allowlist,
        warnings=warnings,
    )


def render_default_config() -> str:
    """The config file written by ``slopblocker init-config``."""
    def block(items: List[str], indent: str = "    ") -> str:
        return "\n".join(indent + item for item in items)

    harsher = "\n".join("    # " + item for item in HARSHER_PATTERNS)

    return """\
# slopblocker configuration
# ---------------------------------------------------------------------------
# Patterns are case-insensitive, accent-insensitive phrases. "şarkıyı tahmin
# et" also matches "SARKIYI TAHMIN ET". Word boundaries are enforced, so
# "guess the song" does not match "guess the songs".
# Add a "re:" prefix to use a raw regular expression.
# ---------------------------------------------------------------------------

[general]
# How often window titles are read, in seconds.
poll_interval = 0.5

# Seconds before the same title can be punished again.
cooldown = 30

# kill     = XKillClient, the window vanishes instantly, no save prompt.
#            NOTE: Chrome uses one X connection, so ALL Chrome windows die.
# graceful = polite WM_DELETE_WINDOW close of just that window.
close_mode = kill

# auto | xlib | xdotool   (auto prefers XKillClient, falls back to xdotool)
kill_method = auto

# true  = stop the video first, then show the image (feels instant)
# false = show the image, then stop the video
kill_before_overlay = true

# How long the image stays on screen, in seconds.
overlay_duration = 1.2

# auto | tk | feh | imv | none
overlay_mode = auto

# Leave empty to use the bundled assets/noslop.png.
# A relative path is looked up next to this file first.
image =

log_level = INFO


[windows]
# Only windows whose WM_CLASS contains one of these are considered.
wm_class_contains = chrome, chromium

# Extra titles to never touch, one per line.
title_ignore =

# true = only punish if the matching window is the focused one.
only_active = false


[patterns]
# --- the classics ---
slop =
{patterns}

# --- Turkish ---
turkish =
{patterns_tr}

# Uncomment any of these to get much stricter:
harsher =
{harsher}


[allowlist]
# If the title also contains one of these, it is left alone.
rescue =
{allowlist}
""".format(
        patterns=block(DEFAULT_PATTERNS[:18]),
        patterns_tr=block(DEFAULT_PATTERNS[18:]),
        harsher=harsher,
        allowlist=block(DEFAULT_ALLOWLIST),
    )


def write_default_config(path: Optional[Path] = None, force: bool = False) -> Path:
    target = Path(path).expanduser() if path else default_config_path()
    if target.exists() and not force:
        raise ConfigError(
            "%s already exists (use --force to overwrite)" % target)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(render_default_config(), encoding="utf-8")
    return target
