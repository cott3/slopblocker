#!/usr/bin/env python3
"""Regenerate assets/noslop.png.

Only needed if you want to change the default warning image; the shipped PNG is
already built. Any image works -- point ``image =`` in the config at it.

    python3 tools/make_default_image.py [output.png]
"""

import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter, ImageFont

WIDTH, HEIGHT = 1920, 1080
BG = (10, 10, 12)
RED = (255, 43, 43)
DIM_RED = (120, 20, 24)
GREY = (150, 150, 158)

FONT_CANDIDATES = [
    "C:/Windows/Fonts/impact.ttf",
    "C:/Windows/Fonts/arialbd.ttf",
    "C:/Windows/Fonts/ariblk.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
    "/usr/share/fonts/truetype/msttcorefonts/Impact.ttf",
]


def load_font(size):
    for path in FONT_CANDIDATES:
        if Path(path).is_file():
            try:
                return ImageFont.truetype(path, size)
            except OSError:
                continue
    return ImageFont.load_default()


def tracked(draw, text, font, fill, center, tracking=0.0):
    """Draw text with letter spacing, centred on ``center``.

    Returns the bottom edge in pixels so callers can lay out what follows.
    """
    widths = [draw.textlength(ch, font=font) for ch in text]
    total = sum(widths) + tracking * max(0, len(text) - 1)
    x = center[0] - total / 2.0
    bottom = center[1]
    for char, width in zip(text, widths):
        box = draw.textbbox((x, center[1]), char, font=font, anchor="lm")
        bottom = max(bottom, box[3])
        draw.text((x, center[1]), char, font=font, fill=fill, anchor="lm")
        x += width + tracking
    return bottom
    return total


def fit_font(draw, text, max_width, start=340, tracking=0.0):
    size = start
    while size > 40:
        font = load_font(size)
        width = (sum(draw.textlength(ch, font=font) for ch in text)
                 + tracking * max(0, len(text) - 1))
        if width <= max_width:
            return font
        size -= 8
    return load_font(72)


def main():
    out = Path(sys.argv[1]) if len(sys.argv) > 1 else (
        Path(__file__).resolve().parent.parent / "assets" / "noslop.png")
    out.parent.mkdir(parents=True, exist_ok=True)

    base = Image.new("RGB", (WIDTH, HEIGHT), BG)
    draw = ImageDraw.Draw(base)

    # faint red glow behind the text
    glow = Image.new("L", (96, 54), 0)
    ImageDraw.Draw(glow).ellipse((8, 4, 88, 50), fill=90)
    glow = glow.filter(ImageFilter.GaussianBlur(6)).resize((WIDTH, HEIGHT))
    base.paste(Image.new("RGB", (WIDTH, HEIGHT), (70, 6, 10)), (0, 0), glow)
    draw = ImageDraw.Draw(base)

    # diagonal texture
    for offset in range(-HEIGHT, WIDTH, 90):
        draw.line([(offset, HEIGHT), (offset + HEIGHT, 0)], fill=(16, 12, 14), width=2)

    # thin frame
    draw.rectangle((48, 48, WIDTH - 49, HEIGHT - 49), outline=DIM_RED, width=4)

    title = "NO SLOP"
    font = fit_font(draw, title, WIDTH - 420, start=420, tracking=14)
    title_y = int(HEIGHT * 0.45)
    bottom = tracked(draw, title, font, (250, 250, 252),
                     (WIDTH / 2, title_y), tracking=14)

    # red rule hugging the bottom of the letters
    rule_y = bottom + 34
    rule_width = 760
    draw.rectangle(
        (WIDTH / 2 - rule_width / 2, rule_y,
         WIDTH / 2 + rule_width / 2, rule_y + 10),
        fill=RED,
    )

    subtitle_font = load_font(52)
    tracked(draw, "WINDOW TERMINATED", subtitle_font, RED,
            (WIDTH / 2, rule_y + 96), tracking=16)

    caption_font = load_font(30)
    tracked(draw, "guess the song  ·  smash or pass  ·  would you rather  ·  bu mu şu mu",
            caption_font, GREY, (WIDTH / 2, HEIGHT - 190), tracking=2)

    tag_font = load_font(26)
    draw.text((80, HEIGHT - 116), "slopblocker", font=tag_font, fill=DIM_RED)
    draw.text((WIDTH - 80, HEIGHT - 116), "go outside", font=tag_font,
              fill=(70, 70, 76), anchor="ra")

    base.save(str(out), "PNG", optimize=True)
    print("wrote %s (%dx%d, %d KB)"
          % (out, WIDTH, HEIGHT, out.stat().st_size // 1024))


if __name__ == "__main__":
    main()
