# slopblocker

Watches Chrome window titles on X11 and, when a title looks like a "slop video"
(`guess the song`, `smash or pass`, `bu mu şu mu`, ...), flashes a fullscreen
warning image and kills the window.

It is a self-imposed attention blocker, not a content filter: no network, no
blocklists, no accounts. One small daemon, one config file.

---

## What it actually does

Every `poll_interval` seconds the daemon:

1. reads the top-level X window list (`_NET_CLIENT_LIST`) and each title
   (`_NET_WM_NAME`)
2. skips windows whose `WM_CLASS` does not contain `chrome` or `chromium`
3. folds the title to ASCII lowercase (`Şarkıyı` -> `sarkiyi`), strips the
   ` - Google Chrome` suffix, and checks it against the pattern list
4. on a match: kills the window with `XKillClient`, then shows the image
   fullscreen for `overlay_duration` seconds

A cooldown keyed by title stops the same thing from being punished in a loop
while Chrome is still shutting down.

> **Warning, read this once.** `close_mode = kill` sends `XKillClient`, which
> tears down the *client's* X connection. Chrome multiplexes every window over
> one connection, so **all Chrome windows die**, not only the offending one,
> and nothing gets a chance to save. Chrome will usually offer session restore
> on the next launch. If that is too violent, set `close_mode = graceful` and
> only the offending window closes (Chrome may still ask you to confirm).

---

## Requirements

| | |
|---|---|
| Session | X11 (Xorg). Wayland is not supported, see [Known limits](#known-limits) |
| Python | 3.8 or newer |
| Packages | `python3-xlib` (required), `python3-tk` **or** `feh` (image), `xdotool` (optional fallback killer) |

On Debian / Ubuntu / Pardus:

```sh
sudo apt install python3-xlib python3-tk xdotool
```

## Install

Copy this directory to the Linux machine (it was developed on Windows), then:

```sh
cd slopblocker
chmod +x install.sh uninstall.sh   # Git/scp from Windows drops the exec bit
./install.sh                 # install + enable + start
./install.sh --dry-run       # install, but only log matches
./install.sh --no-enable     # install files, do not touch systemd
```

It installs to `~/.local/lib/slopblocker`, writes
`~/.config/slopblocker/config.ini` if absent, drops a `slopblocker` launcher in
`~/.local/bin`, installs `~/.config/systemd/user/slopblocker.service`, runs a
pre-flight `diagnose`, and enables the user service. No root needed.

`~/.local/bin` is on `PATH` by default on Debian-family systems. If not, call
`~/.local/bin/slopblocker` or add the directory to `~/.profile`.

### Try it safely first

```sh
# does my pattern list catch this title?
slopblocker match "Guess The Song! - YouTube - Google Chrome"

# what does the daemon currently see?
slopblocker diagnose

# one pass, no side effects
slopblocker run --once

# log matches without killing anything
slopblocker run --dry-run
```

`diagnose` is the one to run when something is wrong: it prints the session
type, whether `python-xlib` is importable, which overlay backend was chosen,
and the live window inventory with each title already matched against your
patterns.

---

## Configuration

`~/.config/slopblocker/config.ini` (created by the installer, heavily
commented). The options that matter:

| Option | Default | Meaning |
|---|---|---|
| `poll_interval` | `0.5` | seconds between title scans |
| `cooldown` | `30` | seconds before the same title can be punished again |
| `close_mode` | `kill` | `kill` (XKillClient) or `graceful` (WM_DELETE_WINDOW) |
| `kill_method` | `auto` | `auto`, `xlib`, or `xdotool` |
| `kill_before_overlay` | `true` | stop the video first, then show the image |
| `overlay_duration` | `1.2` | seconds the image stays up |
| `overlay_mode` | `auto` | `auto`, `tk`, `feh`, `imv`, `none` |
| `image` | *(empty)* | path to your image; empty uses `assets/noslop.png` |
| `wm_class_contains` | `chrome, chromium` | which windows are candidates |
| `only_active` | `false` | `true` = only punish the focused window |
| `title_ignore` | *(empty)* | titles to never touch, one per line |

### Patterns

Patterns are **case-insensitive and accent-insensitive phrases**, and the words
may be separated by anything that is not a letter -- so `this or that` also
catches `this-or-that` and `This | That`. Word boundaries are enforced:
`guess the song` does **not** match `guess the songs`.

```
[patterns]
slop =
    guess the song
    smash or pass
    bu mu şu mu
    re:^(?:guess|name) that (?:song|tune)$
```

A `re:` prefix means raw regular expression, matched against the folded title
with `re.IGNORECASE` and word boundaries.

```
[allowlist]
rescue =
    tutorial
    explained
    how to
```

If the title contains an allowlist phrase, it is left alone -- this is what
keeps "how to guess the song by ear" alive. `re:` works here too.

The generated config ships a commented-out `harsher` block (`reacting to`,
`mukbang`, `prank`, ...) that you can uncomment if you want it stricter.

### Your own image

Drop any PNG/JPG anywhere and point `image =` at it. A bare filename is looked
up next to the config file first, then next to the install directory. The
default is a 1920x1080 "NO SLOP" card; regenerate it with
`python3 tools/make_default_image.py` (needs Pillow).

The overlay is scaled to *cover* the screen, so any aspect ratio works.

---

## How the service runs

It is a **systemd user** unit, because it needs your X session:

```
~/.config/systemd/user/slopblocker.service
```

A user service does not inherit `DISPLAY` from your shell, so the unit pins
`DISPLAY=:0` and `XAUTHORITY=~/.Xauthority`. If yours differs, override it in
`~/.config/slopblocker/env`:

```
DISPLAY=:1
XAUTHORITY=/home/you/.Xauthority
```

```sh
systemctl --user status slopblocker
systemctl --user restart slopblocker
journalctl --user -u slopblocker -f
```

The daemon retries with exponential backoff if X is not up yet or the session
restarts, so `After=graphical-session.target` not resolving is harmless.

---

## Troubleshooting

**`cannot open X display ':0'`** -- wrong `DISPLAY`, or running from a system
unit instead of a user unit. Check the value inside your session
(`echo $DISPLAY`), put it in the env file, `systemctl --user restart`.
Also make sure `XAUTHORITY` points at a readable file.

**`python-xlib is not installed`** -- `sudo apt install python3-xlib`. Verify
with `python3 -c "import Xlib; print(Xlib.__version__)"`.

**Nothing ever matches** -- run `run --dry-run` and watch. Titles are only
what the page sets: a video called "Part 4" is invisible to this tool. Confirm
the window is in the list and its `WM_CLASS` contains `chrome`.

**`no overlay backend available`** -- install `python3-tk` (preferred) or
`feh`.

**The service exits immediately** -- `journalctl --user -u slopblocker -n 50`
shows the traceback; it is always started with `Restart=always`, so a clean
exit means a config error.

---

## Known limits

* **Wayland is not supported.** Wayland deliberately forbids global window
  enumeration. Each compositor would need its own bridge (a KWin script on
  Plasma, a Shell extension on GNOME, `swaymsg` on sway). If you ever switch,
  the matcher and overlay still work; only `x11.py` needs a replacement.
* **Killing is browser-wide**, see the warning above.
* **Chrome restores sessions**, so a killed slop tab can come back. Lowering
  `cooldown` makes the daemon catch it again immediately, which is usually
  enough friction to win.
* **Titles are the only signal.** Recommendations, thumbnails and a video
  literally titled "video" are out of reach without reading the tab URL.
* Titled slop in a non-Chrome browser needs that browser's `wm_class` added.

## Uninstall

```sh
./uninstall.sh           # stop, disable, remove code; keep config
./uninstall.sh --purge   # also remove ~/.config/slopblocker
```

## Development

```sh
python3 -m unittest discover -s tests -v
```

The tests cover folding, matching, the config parser and the daemon glue --
everything that does not need an X server, so they run on any OS. `x11.py`,
`overlay.py` and `systemd/` can only be verified on the real machine; that is
what `diagnose` is for.

Layout:

```
slopblocker/
  slopblocker/
    __main__.py   CLI: run / diagnose / match / patterns / init-config / overlay
    config.py     INI config, defaults, path resolution
    matcher.py    folding + phrase/regex matching (stdlib only)
    x11.py        python-xlib backend: list windows, XKillClient, graceful close
    overlay.py    fullscreen image: Tk, feh, or imv
    daemon.py     the poll loop, cooldown, dry-run
  assets/noslop.png
  systemd/slopblocker.service
  tools/make_default_image.py
  tests/test_matcher.py
  install.sh
  uninstall.sh
```
