"""Tests for the platform-independent half: folding and matching.

Runs anywhere, with no X server and no third-party packages:

    python3 -m unittest discover -s tests -v
"""

import contextlib
import io
import os
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from slopblocker import config as config_mod            # noqa: E402
from slopblocker.matcher import (                        # noqa: E402
    Matcher,
    fold,
    strip_browser_suffix,
)

DEFAULTS = Matcher(config_mod.DEFAULT_PATTERNS, config_mod.DEFAULT_ALLOWLIST)


class TestFold(unittest.TestCase):
    def test_turkish_letters(self):
        self.assertEqual(fold("şarkıyı tahmin et"), "sarkiyi tahmin et")
        self.assertEqual(fold("ŞARKIYI TAHMİN ET"), "sarkiyi tahmin et")
        self.assertEqual(fold("Öpücük mü tokat mı?"), "opucuk mu tokat mi?")

    def test_whitespace_collapse(self):
        self.assertEqual(fold("  guess \t the\nsong  "), "guess the song")

    def test_accents_gone(self):
        self.assertEqual(fold("Café Crème"), "cafe creme")


class TestStripSuffix(unittest.TestCase):
    def test_google_chrome(self):
        self.assertEqual(
            strip_browser_suffix("Guess The Song! - YouTube - Google Chrome"),
            "Guess The Song! - YouTube")

    def test_em_dash(self):
        self.assertEqual(
            strip_browser_suffix("Slop \u2014 Google Chrome"), "Slop")

    def test_no_suffix(self):
        self.assertEqual(strip_browser_suffix("Plain title"), "Plain title")


class TestMatching(unittest.TestCase):
    def test_basic_match(self):
        self.assertTrue(DEFAULTS.is_blocked(
            "Guess The Song! - YouTube - Google Chrome"))

    def test_case_insensitive(self):
        self.assertTrue(DEFAULTS.is_blocked("SMASH OR PASS - YouTube"))

    def test_word_boundary_blocks_plurals(self):
        # "guess the song" must not fire inside "guess the songs"
        self.assertFalse(DEFAULTS.is_blocked("guess the songs - YouTube"))

    def test_hyphenated_title_matches(self):
        self.assertTrue(DEFAULTS.is_blocked("this-or-that challenge - YouTube"))

    def test_pipe_separated_title_matches(self):
        self.assertTrue(DEFAULTS.is_blocked(
            "Bu Mu | Şu Mu | Bölüm 4 - YouTube"))

    def test_separator_does_not_span_letters(self):
        # "this" ... "or" ... "that" with real words in between is not a match.
        self.assertFalse(DEFAULTS.is_blocked("this is not or that either"))

    def test_extra_punctuation_matches(self):
        self.assertTrue(DEFAULTS.is_blocked(
            "WOULD YOU RATHER?! (ft. friends) - YouTube"))

    def test_turkish_pattern(self):
        self.assertTrue(DEFAULTS.is_blocked(
            "Şarkıyı Tahmin Et | Bölüm 12 - YouTube - Google Chrome"))
        # ...and the same title typed without Turkish characters
        self.assertTrue(DEFAULTS.is_blocked(
            "Sarkiyi Tahmin Et | Bolum 12 - YouTube"))

    def test_turkish_dotless_i_title(self):
        self.assertTrue(DEFAULTS.is_blocked("BU MU ŞU MU - YouTube"))

    def test_unrelated_title_is_clean(self):
        self.assertFalse(DEFAULTS.is_blocked(
            "Rust ownership explained - YouTube - Google Chrome"))
        self.assertFalse(DEFAULTS.is_blocked("Inbox (3) - mail - Google Chrome"))

    def test_allowlist_rescues(self):
        result = DEFAULTS.check(
            "How to guess the song by ear - music theory - YouTube")
        self.assertFalse(result.matched)
        self.assertEqual(result.allowlisted_by, "how to")

    def test_allowlist_reports_reason(self):
        result = DEFAULTS.check("Guess the song: a documentary - YouTube")
        self.assertFalse(result.matched)
        self.assertIsNotNone(result.allowlisted_by)

    def test_empty_title(self):
        self.assertFalse(DEFAULTS.is_blocked(""))
        self.assertFalse(DEFAULTS.is_blocked("   "))

    def test_match_reports_pattern(self):
        result = DEFAULTS.check("Tier list time - YouTube")
        self.assertEqual(result.pattern, "tier list")

    def test_describe_is_human_readable(self):
        self.assertIn("MATCH", DEFAULTS.check("smash or pass").describe())


class TestCustomPatterns(unittest.TestCase):
    def test_raw_regex_pattern(self):
        matcher = Matcher([r"re:(?:guess|name) that (?:song|tune)"])
        self.assertTrue(matcher.is_blocked("name that tune - YouTube"))
        self.assertFalse(matcher.is_blocked("name that movie"))

    def test_regex_is_not_escaped(self):
        # A regression guard: "re:" content must not be re.escape()d.
        matcher = Matcher([r"re:\d+\s*\|\s*slop"])
        self.assertTrue(matcher.is_blocked("7 | slop compilation"))
        self.assertFalse(matcher.is_blocked(r"\d+ \| slop"))

    def test_regex_allowlist(self):
        matcher = Matcher(["smash or pass"], [r"re:^.*\b(?:podcast|episode) \d"])
        self.assertFalse(matcher.is_blocked(
            "Smash or pass - podcast episode 12"))

    def test_empty_matcher(self):
        matcher = Matcher([], [])
        self.assertFalse(matcher.is_blocked("anything at all"))
        self.assertEqual(len(matcher), 0)

    def test_blank_patterns_ignored(self):
        matcher = Matcher(["", "   ", "smash or pass"])
        self.assertEqual(len(matcher), 1)


class TestConfig(unittest.TestCase):
    def test_defaults_without_a_file(self):
        cfg = config_mod.load(str(Path(tempfile.gettempdir())
                                   / "slopblocker-does-not-exist.ini"))
        self.assertEqual(cfg.patterns, config_mod.DEFAULT_PATTERNS)
        self.assertEqual(cfg.allowlist, config_mod.DEFAULT_ALLOWLIST)
        self.assertEqual(cfg.general.close_mode, "kill")
        self.assertTrue(cfg.general.kill_before_overlay)
        self.assertTrue(cfg.warnings)

    def test_roundtrip_rendered_config(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / "config.ini"
            config_mod.write_default_config(target)
            cfg = config_mod.load(str(target))
            self.assertEqual(cfg.patterns, config_mod.DEFAULT_PATTERNS)
            self.assertEqual(cfg.allowlist, config_mod.DEFAULT_ALLOWLIST)
            # the commented-out "harsher" block must stay inert
            self.assertNotIn("mukbang", cfg.patterns)
            self.assertEqual(cfg.general.close_mode, "kill")

    def test_refuses_to_overwrite(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / "config.ini"
            config_mod.write_default_config(target)
            with self.assertRaises(config_mod.ConfigError):
                config_mod.write_default_config(target)
            config_mod.write_default_config(target, force=True)

    def test_invalid_choice_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / "config.ini"
            target.write_text("[general]\nclose_mode = nuke\n", encoding="utf-8")
            with self.assertRaises(config_mod.ConfigError):
                config_mod.load(str(target))

    def test_invalid_bool_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / "config.ini"
            target.write_text("[general]\nkill_before_overlay = maybe\n",
                              encoding="utf-8")
            with self.assertRaises(config_mod.ConfigError):
                config_mod.load(str(target))

    def test_custom_patterns_and_windows(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / "config.ini"
            target.write_text(
                "[general]\npoll_interval = 2\ncooldown = 0\n"
                "[windows]\nwm_class_contains = chrome, brave\n"
                "[patterns]\nmine =\n  guess the song\n  re:slop\\s+video\n"
                "[allowlist]\nrescue =\n  tutorial\n",
                encoding="utf-8")
            cfg = config_mod.load(str(target))
            self.assertEqual(cfg.general.poll_interval, 2.0)
            self.assertEqual(cfg.windows.wm_class_contains, ["chrome", "brave"])
            self.assertEqual(cfg.patterns, ["guess the song", r"re:slop\s+video"])
            self.assertTrue(cfg.windows.accepts_class("Google-chrome"))
            self.assertFalse(cfg.windows.accepts_class("firefox"))

    def test_tiny_poll_interval_is_clamped(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / "config.ini"
            target.write_text("[general]\npoll_interval = 0.001\n",
                              encoding="utf-8")
            cfg = config_mod.load(str(target))
            self.assertGreaterEqual(cfg.general.poll_interval, 0.05)


class TestDaemonGlue(unittest.TestCase):
    """The parts of daemon.py that do not touch X."""

    def test_ignore_title(self):
        cfg = config_mod.load(str(Path(tempfile.gettempdir())
                                   / "slopblocker-does-not-exist.ini"))
        cfg.windows.title_ignore = ["chillhop", "lofi"]
        from slopblocker.daemon import _ignore_title

        self.assertTrue(_ignore_title(cfg, "LoFi beats - YouTube"))
        self.assertFalse(_ignore_title(cfg, "smash or pass"))


class TestDiagnoseSmoke(unittest.TestCase):
    """diagnose must survive whatever the host throws at it.

    Regression: some distro builds expose ``Xlib.__version__`` as a tuple,
    which used to raise TypeError and abort the whole report.
    """

    def _diagnose_with(self, version):
        from slopblocker import __main__ as cli

        fake = types.ModuleType("Xlib")
        if version is not None:
            fake.__version__ = version
        fake.X = types.SimpleNamespace(AnyPropertyType=0)
        fake.error = types.SimpleNamespace(XError=Exception)
        fake.display = types.SimpleNamespace(
            Display=lambda *a, **k: (_ for _ in ()).throw(
                RuntimeError("no display in this test")))

        args = types.SimpleNamespace(
            config=str(Path(tempfile.gettempdir()) / "slopblocker-absent.ini"))
        buffer = io.StringIO()
        with mock.patch.dict(sys.modules, {"Xlib": fake}), \
                contextlib.redirect_stdout(buffer):
            code = cli._cmd_diagnose(args)
        return code, buffer.getvalue()

    def test_tuple_version_does_not_crash(self):
        code, output = self._diagnose_with((0, 33))
        self.assertEqual(code, 1)          # no X server in the test env
        self.assertIn("ok (0.33)", output)
        # it must get past the version line to the X section
        self.assertIn("X connection", output)

    def test_plain_string_version(self):
        _code, output = self._diagnose_with("0.33")
        self.assertIn("ok (0.33)", output)

    def test_missing_version(self):
        _code, output = self._diagnose_with(None)
        self.assertIn("ok (unknown)", output)

    def test_version_string_helper(self):
        from slopblocker.__main__ import _version_string

        self.assertEqual(_version_string(types.SimpleNamespace(
            __version__=(1, 2, 3))), "1.2.3")
        self.assertEqual(_version_string(types.SimpleNamespace(
            __version__="1.2.3")), "1.2.3")
        self.assertEqual(_version_string(types.SimpleNamespace()), "unknown")


if __name__ == "__main__":
    unittest.main(verbosity=2)
